const express = require("express");
const cors = require("cors");
const app = express();
const port = 3000;

app.use(cors());

const simulations = {
  remove_biometric_auth: {
    title: "Remove Biometric Authentication",
    trustScore: 61,
    fraudRisk: "High",
    sustainabilityImpact: "Neutral",
    customerFeedback: [
      "I felt uneasy paying without biometric security.",
      "Checkout was faster but less secure.",
      "Would prefer if biometric was optional."
    ]
  },
  switch_to_bamboo_packaging: {
    title: "Switch to Bamboo Packaging",
    trustScore: 88,
    fraudRisk: "Low",
    sustainabilityImpact: "Reduced CO2 emissions by 15%",
    customerFeedback: [
      "Love the eco-friendly packaging!",
      "Packaging felt premium and responsible.",
      "Hope they keep this sustainable choice."
    ]
  },
  remove_2fa_checkout: {
    title: "Remove 2FA in Checkout Process",
    trustScore: 55,
    fraudRisk: "Very High",
    sustainabilityImpact: "Neutral",
    customerFeedback: [
      "Checkout was fast but I worry about fraud now.",
      "I miss the extra layer of security.",
      "Would not trust my card info without 2FA."
    ]
  }
};

app.get("/api/simulations", (req, res) => {
  res.json(simulations);
});

app.listen(port, () => {
  console.log(`RetailVerse backend running at http://localhost:${port}`);
});