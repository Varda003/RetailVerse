async function fetchSimulations() {
  const res = await fetch("http://localhost:3000/api/simulations");
  const data = await res.json();
  return data;
}

function populateDecisions(data) {
  const select = document.getElementById("decisionSelect");
  Object.keys(data).forEach(key => {
    const option = document.createElement("option");
    option.value = key;
    option.textContent = data[key].title;
    select.appendChild(option);
  });

  select.addEventListener("change", () => showResults(data[select.value]));
  showResults(data[select.value]);
}

function showResults(simulation) {
  const results = document.getElementById("results");
  results.innerHTML = `
    <p><strong>Trust Score:</strong> ${simulation.trustScore}%</p>
    <p><strong>Fraud Risk:</strong> ${simulation.fraudRisk}</p>
    <p><strong>Sustainability Impact:</strong> ${simulation.sustainabilityImpact}</p>
    <h3>Customer Feedback:</h3>
    <ul>
      ${simulation.customerFeedback.map(f => `<li>${f}</li>`).join("")}
    </ul>
  `;
}

fetchSimulations().then(populateDecisions);